plugins {
    alias(libs.plugins.android.application) apply false
}

// ADD THIS BLOCK FOR GOOGLE SERVICES
buildscript {
    dependencies {
        classpath("com.google.gms:google-services:4.4.2")
    }
}
